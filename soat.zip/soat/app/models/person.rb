class Person < ApplicationRecord
	validates :num_documento, presence: true, uniqueness: true
	validates :tipo_documento, presence: true
	validates :nombres, presence: true
	validates :apellidos, presence: true
	validates :correo, presence: true
	validates :telefono, presence: true
	has_many :vehicles
end
