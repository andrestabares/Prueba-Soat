class PaymentMailer < ApplicationMailer
	def new_payment(payment)
		@payment = payment
		@vehicle = Vehicle.find(@payment.vehicle)
		@person = Person.find(@vehicle.person)

		mail(to:@person.correo, subjet: "Resumen de compra")
	end
end
