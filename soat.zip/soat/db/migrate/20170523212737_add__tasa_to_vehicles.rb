class AddTasaToVehicles < ActiveRecord::Migration[5.0]
  def change
    add_column :vehicles, :tasa, :decimal
    add_column :vehicles, :prima, :decimal
    add_column :vehicles, :fosyga, :decimal
    add_column :vehicles, :sub_total, :decimal
  end
end
