class VehiclesController < ApplicationController
  before_action :set_person
  
  def index


  end
  
  def show
  	@vehicle = Vehicle.find(params[:id])
  end

  def new
  	@vehicle = Vehicle.new
  end

  def create
  	@vehicle = Vehicle.new(vehicle_params)
    @vehicle.person = @person
    if @vehicle.clase == "MOTOS"
      if @vehicle.subtipo < 100
        @vehicle.tasa = 8.26
        @vehicle.prima =203.1
      elsif @vehicle.subtipo > 100 and @vehicle.subtipo <=200
        @vehicle.tasa = 11.09
        @vehicle.prima = 272.7
      elsif @vehicle.subtipo > 200
        @vehicle.tasa =12.51
        @vehicle.prima =307.6
      end
    end
    if @vehicle.clase == "CAMPEROS Y CAMIONETAS"
        if @vehicle.subtipo < 1500 and @vehicle.edad>0 and @vehicle.edad<= 9
          @vehicle.tasa =13.29
          @vehicle.prima =326.8
        elsif @vehicle.subtipo < 1500 and @vehicle.edad> 9
            @vehicle.tasa = 15.99
            @vehicle.prima =393.2
        elsif @vehicle.subtipo >= 1500 and @vehicle.subtipo<=2500 and @vehicle.edad>0 and @vehicle.edad<= 9
            @vehicle.tasa = 15.88
            @vehicle.prima =390.4
          elsif  @vehicle.subtipo >= 1500 and @vehicle.subtipo<=2500 and @vehicle.edad>9
              @vehicle.tasa = 15.82
              @vehicle.prima =462.7
            elsif @vehicle.subtipo > 2500 and @vehicle.edad>0 and @vehicle.edad<= 9
                 @vehicle.tasa = 18.63
                 @vehicle.prima =458.1
               elsif  @vehicle.subtipo > 2500 and @vehicle.edad>9
                   @vehicle.tasa = 21.39
                   @vehicle.prima =525.9
        end
    end
    if @vehicle.clase == "CARGA O MIXTO"
      if @vehicle.subtipo < 5
        @vehicle.tasa =14.90
        @vehicle.prima =366.3
      elsif @vehicle.subtipo >= 5 and @vehicle.subtipo<=15
         @vehicle.tasa =21.53
         @vehicle.prima =529.4
        elsif  @vehicle.subtipo >15 
           @vehicle.tasa =27.23
           @vehicle.prima =669.6
      end
    end

    if @vehicle.clase == "OFICIALES ESPECIALES"
      if @vehicle.subtipo < 1500
        @vehicle.tasa =16.77
        @vehicle.prima =412.3
      elsif @vehicle.subtipo >= 1500 and @vehicle.subtipo <= 2500
          @vehicle.tasa =21.15
          @vehicle.prima =520
        elsif @vehicle.subtipo > 2500
             @vehicle.tasa =25.36
             @vehicle.prima =623.6

      end
    end

    if @vehicle.clase == "AUTOS FAMILIARES"
      if @vehicle.subtipo < 1500 and @vehicle.edad>0 and @vehicle.edad<= 9
          @vehicle.tasa =7.48
          @vehicle.prima =183.9
        elsif @vehicle.subtipo < 1500 and @vehicle.edad> 9
             @vehicle.tasa =9.93
             @vehicle.prima =244.1
        elsif @vehicle.subtipo >= 1500 and @vehicle.subtipo<=2500 and @vehicle.edad>0 and @vehicle.edad<= 9
               @vehicle.tasa =9.12
               @vehicle.prima =224.2
             elsif @vehicle.subtipo >= 1500 and @vehicle.subtipo<=2500 and @vehicle.edad>9
                 @vehicle.tasa =11.35
                 @vehicle.prima =279.1
               elsif  @vehicle.subtipo > 2500 and @vehicle.edad>0 and @vehicle.edad<= 9
                   @vehicle.tasa =10.66
                   @vehicle.prima =262.1
                 elsif ehicle.subtipo > 2500 and @vehicle.edad>9
                     @vehicle.tasa =12.65
                     @vehicle.prima =311
      end
    end

    if  @vehicle.clase == "VEHICULOS PARA SEIS O MAS PASAJEROS"
      if @vehicle.subtipo < 2500 and @vehicle.edad>0 and @vehicle.edad<= 9
          @vehicle.tasa =13.37
          @vehicle.prima =328.7
        elsif  @vehicle.subtipo < 2500 and @vehicle.edad>9
             @vehicle.tasa =17.08
             @vehicle.prima =420
           elsif @vehicle.subtipo >= 2500 and @vehicle.edad>0 and @vehicle.edad<= 9
                @vehicle.tasa =17.91
                @vehicle.prima =440
              elsif @vehicle.subtipo >= 2500 and @vehicle.edad>9
                  @vehicle.tasa =21.51
                  @vehicle.prima =528.9
      end
    end

    if @vehicle.clase == "AUTOS DE NEGOCIOS Y TAXIS"
      if @vehicle.subtipo < 1500 and @vehicle.edad>0 and @vehicle.edad<= 9
          @vehicle.tasa =9.28
          @vehicle.prima =228.2
          elsif @vehicle.subtipo < 1500 and @vehicle.edad> 9
             @vehicle.tasa =11.60
             @vehicle.prima =285.2
              elsif @vehicle.subtipo >= 1500 and @vehicle.subtipo<=2500 and @vehicle.edad>0 and @vehicle.edad<= 9
               @vehicle.tasa =11.54
               @vehicle.prima =283.7
             elsif @vehicle.subtipo >= 1500 and @vehicle.subtipo<=2500 and @vehicle.edad>9
                 @vehicle.tasa =14.27
                 @vehicle.prima =350.9
                 elsif  @vehicle.subtipo > 2500 and @vehicle.edad>0 and @vehicle.edad<= 9
                   @vehicle.tasa =14.90
                   @vehicle.prima =366.3
                 elsif ehicle.subtipo > 2500 and @vehicle.edad>9
                     @vehicle.tasa =17.49
                     @vehicle.prima =430
      end
    end
    if @vehicle.clase == "BUSES Y BUSETAS DE SERVICIO PUBLICO URBANO"
      @vehicle.tasa =21.81
      @vehicle.prima =536.3
    end
    if @vehicle.clase == "SERVICIO PUBLICO INTERMUNICIPAL"
      if @vehicle.subtipo < 10
          @vehicle.tasa =22.01
          @vehicle.prima =541.2
        elsif @vehicle.subtipo >= 10
             @vehicle.tasa =31.96
             @vehicle.prima =785.9
      end
    end
    @vehicle.fosyga = @vehicle.prima * 0.5
    @vehicle.sub_total = @vehicle.fosyga + @vehicle.prima

    unless (Vehicle.find_by placa: @vehicle.placa).nil?
      		redirect_to "/people/#{@person.id}/vehicles/new"
          flash[:notice] = "El vehículo con esta placa ya esta asegurado"
      	else
      		if @vehicle.save
      		  redirect_to "/people/#{@person.id}/vehicles/#{@vehicle.id}/payments/new"
          else
            puts "EEEEEEEELSEEEEEEE"
            puts @vehicle.person
          end
      	end
    end

  def set_person
      @person = Person.find(params[:person_id])
  end
 

  def vehicle_params
      params.require(:vehicle).permit(:placa, :clase, :subtipo, :edad, :pasajeros, :cilindraje, :toneladas)
  end
end
