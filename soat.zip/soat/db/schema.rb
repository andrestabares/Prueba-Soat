# This file is auto-generated from the current state of the database. Instead
# of editing this file, please use the migrations feature of Active Record to
# incrementally modify your database, and then regenerate this schema definition.
#
# Note that this schema.rb definition is the authoritative source for your
# database schema. If you need to create the application database on another
# system, you should be using db:schema:load, not running all the migrations
# from scratch. The latter is a flawed and unsustainable approach (the more migrations
# you'll amass, the slower it'll run and the greater likelihood for issues).
#
# It's strongly recommended that you check this file into your version control system.

ActiveRecord::Schema.define(version: 20170523212737) do

  create_table "payments", force: :cascade do |t|
    t.string   "num_tajeta"
    t.string   "nombre_titular"
    t.date     "fecha_vencimiento"
    t.integer  "codigo"
    t.integer  "cuotas"
    t.integer  "vehicle_id"
    t.datetime "created_at",        null: false
    t.datetime "updated_at",        null: false
    t.index ["vehicle_id"], name: "index_payments_on_vehicle_id"
  end

  create_table "people", force: :cascade do |t|
    t.string   "tipo_documento"
    t.string   "num_documento"
    t.string   "nombres"
    t.string   "apellidos"
    t.string   "correo"
    t.string   "telefono"
    t.datetime "created_at",     null: false
    t.datetime "updated_at",     null: false
  end

  create_table "vehicles", force: :cascade do |t|
    t.string   "placa"
    t.string   "clase"
    t.integer  "subtipo"
    t.integer  "edad"
    t.integer  "pasajeros"
    t.integer  "cilindraje"
    t.float    "toneladas"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.integer  "person_id"
    t.decimal  "tasa"
    t.decimal  "prima"
    t.decimal  "fosyga"
    t.decimal  "sub_total"
    t.index ["person_id"], name: "index_vehicles_on_person_id"
  end

end
