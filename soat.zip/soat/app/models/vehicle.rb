class Vehicle < ApplicationRecord
	validates :placa, presence: true, uniqueness: true
	validates :clase, presence: true
	validates :subtipo, presence: true
	validates :edad, presence: true
	validates :pasajeros, presence: true
	validates :cilindraje, presence: true
	validates :toneladas, presence: true
	belongs_to :person
	has_many :payments
end
