class CreatePayments < ActiveRecord::Migration[5.0]
  def change
    create_table :payments do |t|
      t.string :num_tajeta
      t.string :nombre_titular
      t.date :fecha_vencimiento
      t.integer :codigo
      t.integer :cuotas
      t.references :vehicle, foreign_key: true

      t.timestamps
    end
  end
end
