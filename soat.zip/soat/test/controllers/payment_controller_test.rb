require 'test_helper'

class PaymentControllerTest < ActionDispatch::IntegrationTest
  test "should get num_tarjeta" do
    get payment_num_tarjeta_url
    assert_response :success
  end

  test "should get titular" do
    get payment_titular_url
    assert_response :success
  end

  test "should get fecha_vencimiento:date" do
    get payment_fecha_vencimiento:date_url
    assert_response :success
  end

  test "should get codigo:integer" do
    get payment_codigo:integer_url
    assert_response :success
  end

  test "should get cuotas:integer" do
    get payment_cuotas:integer_url
    assert_response :success
  end

end
