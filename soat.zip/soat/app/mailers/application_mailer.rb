class ApplicationMailer < ActionMailer::Base
  default from: 'soat@gmail.com'
  layout nil
end
