class Payment < ApplicationRecord
  belongs_to :vehicle
  validates :num_tajeta, presence: true
  validates :nombre_titular, presence: true
  validates :fecha_vencimiento, presence: true
  validates :codigo, presence: true
  validates :cuotas, presence: true

  after_create :send_mail

  def send_mail
  	PaymentMailer.new_payment(self).deliver_later
  end
end
