class AddPersonIdToVehicles < ActiveRecord::Migration[5.0]
  def change
    add_reference :vehicles, :person, foreign_key: true
  end
end
