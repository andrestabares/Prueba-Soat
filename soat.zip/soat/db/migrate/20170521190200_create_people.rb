class CreatePeople < ActiveRecord::Migration[5.0]
  def change
    create_table :people do |t|
      t.string :tipo_documento
      t.string :num_documento
      t.string :nombres
      t.string :apellidos
      t.string :correo
      t.string :telefono

      t.timestamps
    end
  end
end
