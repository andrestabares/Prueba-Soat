Rails.application.routes.draw do
  

  
  resources :people, except: [:delete] do
	  resources :vehicles, except: [:update,:index,:delete] do
	  		resources :payments, except: [:update, :edit,:delete]
	  end
  end
  get "administrador", to: "payments#index"
  get 'vehicles/index'
  get "buscar", to: "welcome#buscar"
  get "buscar_p", to: "people#buscar_persona"
  root 'people#index'
  get 'welcome/index'
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
end
