module VehicleHelper
end
