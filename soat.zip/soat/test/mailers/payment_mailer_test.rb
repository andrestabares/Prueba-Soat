require 'test_helper'

class PaymentMailerTest < ActionMailer::TestCase
  # test "the truth" do
  #   assert true
  # end
end
