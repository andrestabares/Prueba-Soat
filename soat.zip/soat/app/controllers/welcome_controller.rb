class WelcomeController < ApplicationController
  def index
  end
  def show
  	@vehicle= Vehicle.find(params[:placa])
  end

    def buscar
    
    if Vehicle.find_by placa: params[:placa]
      redirect_to welcome_index_path 
      flash[:notice] = "El vehículo con esta placa ya esta asegurado"
      
    else
      redirect_to "/people/new"
    end
    
  end
end
